package Calendar.Event;

public class EventException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L; //keeps eclipse happy 

	public EventException() {
		// TODO Auto-generated constructor stub
	}

	public EventException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public EventException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public EventException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

}
